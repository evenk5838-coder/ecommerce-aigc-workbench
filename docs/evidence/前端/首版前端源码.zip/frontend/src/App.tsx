import { useCallback, useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import { ArrowDownToLine, ArrowUpRight, Check, ChevronDown, Clock3, Cloud, Copy, Download, Film, FolderOpen, Image as ImageIcon, Layers, LayoutGrid, Loader2, Minus, MousePointer2, Plus, RefreshCw, Save, Search, SlidersHorizontal, Sparkles, Square, Trash2, Type, Undo2, Upload, X } from 'lucide-react';
import JSZip from 'jszip';
import { api, ApiError, mediaUrl } from './api';
import { downloadBlob, fitAsset, makeBatch, metadata, moveLayer, newProject, realAssets, renderCanvas, safeName } from './editor';
import type { Asset, Layer, Model, Project, SystemStatus, Task } from './types';

const STORAGE = 'material-studio-project-v1';
const ACTIVE = ['queued','loading','running','postprocess','remote_queued','remote_running','cancel_requested'];
const NAMES: Record<string,string> = {queued:'排队中',loading:'加载中',running:'生成中',postprocess:'保存结果',remote_queued:'云端排队',remote_running:'云端生成',cancel_requested:'已请求取消',succeeded:'已完成',failed:'生成失败',canceled:'已取消',interrupted:'已中断'};
const PRESETS = [{label:'白底主图',prompt:'一瓶无品牌护肤品，纯白背景，柔和棚拍光，真实产品摄影，干净构图，无文字无水印'}, {label:'生活场景',prompt:'护肤品摆放在浅色大理石台面，清晨自然光，清爽浴室场景，真实产品摄影，无文字无水印'}, {label:'高级棚拍',prompt:'护肤品静物摄影，米色背景，精致柔和的光影，留白构图，高级质感，无文字无水印'}];
const ERRORS: Record<string,string> = {AUTH_MISSING:'尚未配置云端 Key，请在后端配置后重试。',AUTH_FAILED:'模型鉴权失败，请检查 Key 与模型开通权限。',BUDGET_NOT_APPROVED:'后端尚未批准云端预算。',BUDGET_EXCEEDED:'已达到本次预算上限，请先核对用量。',MODEL_NOT_DOWNLOADED:'本地模型权重未就位。',CREATE_RESULT_UNKNOWN:'创建结果暂不明确，请先核对云端任务，避免重复扣费。'};
const time = (ms?: number) => ms == null ? '—' : ms < 60000 ? `${(ms/1000).toFixed(1)}秒` : `${(ms/60000).toFixed(1)}分钟`;
function IconButton({ children, label, onClick, disabled = false, active = false }: {children:ReactNode;label:string;onClick:()=>void;disabled?:boolean;active?:boolean}) {
  return <button className={`icon-button ${active?'active':''}`} aria-label={label} title={label} onClick={onClick} disabled={disabled}>{children}</button>;
}
function assetName(a: Asset) { const m=metadata(a); return typeof m.filename==='string'?m.filename:a.kind==='video'?'生成视频':`生成图片 · ${a.width}×${a.height}`; }

export default function App() {
  const [project,setProject]=useState<Project>(newProject);
  const projectRef=useRef(project); const draftRef=useRef<{id:string;version:number}|null>(null);
  const dirty=useRef(0), saved=useRef(0), saving=useRef(false), blocked=useRef(false);
  const [ready,setReady]=useState(false), [saveState,setSaveState]=useState('尚未保存');
  const [models,setModels]=useState<Model[]>([]), [assets,setAssets]=useState<Asset[]>([]), [tasks,setTasks]=useState<Task[]>([]);
  const [system,setSystem]=useState<SystemStatus|null>(null), [usage,setUsage]=useState({budget_cny:0,spent_today_cny:0});
  const [connected,setConnected]=useState(false), [notice,setNotice]=useState(''), [panel,setPanel]=useState<'generate'|'assets'>('generate');
  const [view,setView]=useState<'canvas'|'library'>('canvas'),[taskDrawer,setTaskDrawer]=useState(false),[preview,setPreview]=useState<Asset|null>(null);
  const [selected,setSelected]=useState<string|null>(null),[zoom,setZoom]=useState(1),[undo,setUndo]=useState<Project[]>([]);
  const [kind,setKind]=useState<'image'|'video'>('image'),[modelId,setModelId]=useState(''),[prompt,setPrompt]=useState(PRESETS[0].prompt);
  const [negative,setNegative]=useState(''),[batchCount,setBatchCount]=useState(1),[ratio,setRatio]=useState('1:1');
  const [seed,setSeed]=useState(-1),[steps,setSteps]=useState(25),[duration,setDuration]=useState(5),[reference,setReference]=useState<string|null>(null);
  const [busy,setBusy]=useState(false),[uploading,setUploading]=useState(false),[exporting,setExporting]=useState(false),[query,setQuery]=useState('');
  const [marked,setMarked]=useState<Set<string>>(new Set()),[assetTab,setAssetTab]=useState('all');
  const svgRef=useRef<SVGSVGElement>(null), fileRef=useRef<HTMLInputElement>(null);
  const drag=useRef<{id:string;x:number;y:number;layer:Layer;resize:boolean}|null>(null);
  const pollBusy=useRef(false), initialized=useRef(false);

  const notify=useCallback((message:string)=>setNotice(message),[]);
  const commit=useCallback((next:Project, history=true)=>{
    if(history) setUndo(list=>[...list.slice(-24),structuredClone(projectRef.current)]);
    projectRef.current=next;dirty.current++;setProject(next);setSaveState('待保存');
  },[]);
  const mutate=useCallback((fn:(p:Project)=>Project,history=true)=>commit(fn(projectRef.current),history),[commit]);
  const saveProject=useCallback(async()=>{
    if(saving.current||blocked.current)return;
    saving.current=true;setSaveState('保存中…'); const revision=dirty.current; let completed=false;
    const p=structuredClone(projectRef.current);
    try {
      const content={canvas:p.canvas,assetGroups:p.assetGroups,meta:{name:p.name}};
      const r=draftRef.current?await api.saveDraft(draftRef.current.id,draftRef.current.version,content):await api.createDraft(p.name,content);
      draftRef.current={id:r.draft_id,version:r.version};saved.current=revision;completed=true;
      localStorage.setItem(STORAGE,JSON.stringify({project:projectRef.current,draft:draftRef.current,pending:dirty.current!==revision}));
      setSaveState(dirty.current===revision?'已保存到本机':'待保存');
    } catch(e) {
      setSaveState('保存失败');
      if(e instanceof ApiError&&e.code==='DRAFT_VERSION_CONFLICT')blocked.current=true;
      notify(e instanceof Error?e.message:'草稿保存失败；当前修改仍保存在浏览器恢复副本中。');
    } finally {saving.current=false;if(completed&&dirty.current!==revision)setProject({...projectRef.current});}
  },[notify]);
  const refresh=useCallback(async()=>{
    if(pollBusy.current)return;pollBusy.current=true;
    const result=await Promise.allSettled([api.models(),api.assets(),api.tasks(),api.system(),api.usage()]);
    if(result[0].status==='fulfilled')setModels(result[0].value.items.filter(m=>['doubao-seedream-5-0-flash-260915','doubao-seedance-1-0-pro-fast-251015'].includes(m.id)));
    if(result[1].status==='fulfilled')setAssets(realAssets(result[1].value.items));
    if(result[2].status==='fulfilled')setTasks(result[2].value.items.filter(t=>t.model_id!=='fake-image'));
    if(result[3].status==='fulfilled'){setSystem(result[3].value);setConnected(true);}else setConnected(false);
    if(result[4].status==='fulfilled')setUsage(result[4].value);
    pollBusy.current=false;
  },[]);
  useEffect(()=>{
    if(initialized.current)return;initialized.current=true;
    (async()=>{
      try {
        const raw=localStorage.getItem(STORAGE);
        if(raw){const local=JSON.parse(raw) as {project:Project;draft:{id:string;version:number}|null;pending:boolean};
          if(local.project?.canvas?.layers){projectRef.current=local.project;setProject(local.project);draftRef.current=local.draft;
            if(local.pending){dirty.current=1;setSaveState('已恢复未保存修改');}
            else if(local.draft){const d=await api.draft(local.draft.id);const p={name:d.content.meta?.name||d.name,canvas:d.content.canvas,assetGroups:d.content.assetGroups||{}};
              projectRef.current=p;setProject(p);draftRef.current={id:d.id,version:d.version};setSaveState('已保存到本机');}
          }
        }
      }catch{notify('已保留当前编辑；暂时无法恢复上次后端草稿，请检查服务。');}
      setReady(true);await refresh();
    })();
    const timer=window.setInterval(refresh,2500);return()=>window.clearInterval(timer);
  },[notify,refresh]);
  useEffect(()=>{if(!ready)return;
    localStorage.setItem(STORAGE,JSON.stringify({project,draft:draftRef.current,pending:dirty.current!==saved.current}));
    if(dirty.current===saved.current)return;
    const timer=window.setTimeout(()=>void saveProject(),1100);return()=>window.clearTimeout(timer);
  },[project,ready,saveProject]);
  useEffect(()=>{const list=models.filter(m=>m.kind===kind);if(!list.some(m=>m.id===modelId&&m.downloaded))setModelId((list.find(m=>m.provider==='ark'&&m.downloaded&&m.id.includes('flash'))||list.find(m=>m.provider==='ark'&&m.downloaded)||list.find(m=>m.downloaded))?.id||'');},[models,kind,modelId]);
  useEffect(()=>{if(!notice)return;const timer=window.setTimeout(()=>setNotice(''),8000);return()=>window.clearTimeout(timer);},[notice]);

  const selectedLayer=project.canvas.layers.find(l=>l.id===selected);
  const activeTasks=tasks.filter(t=>ACTIVE.includes(t.status));
  const selectedModel=models.find(m=>m.id===modelId), cloud=selectedModel?.provider==='ark';
  const refAsset=assets.find(a=>a.id===reference);
  const filteredAssets=assets.filter(a=>(assetTab==='all'||(assetTab==='upload'?a.source==='upload':a.kind===assetTab))&&(assetName(a)+' '+String(metadata(a).prompt||'')+' '+(project.assetGroups[a.id]||'')).toLowerCase().includes(query.toLowerCase()));
  const updateLayer=(patch:Partial<Layer>)=>mutate(p=>({...p,canvas:{...p.canvas,layers:p.canvas.layers.map(l=>l.id===selected?{...l,...patch}:l)}}));
  const addAsset=(a:Asset)=>{
    if(a.kind==='video'){setPreview(a);return;}
    const layer=fitAsset(a,projectRef.current.canvas.width,projectRef.current.canvas.height);
    mutate(p=>({...p,canvas:{...p.canvas,layers:[...p.canvas.layers,layer]}}));setSelected(layer.id);setView('canvas');
  };
  const addElement=(type:'text'|'shape')=>{
    const id=crypto.randomUUID(), d=projectRef.current.canvas;
    const layer:Layer={id,type,name:type==='text'?'卖点文案':'背景色块',x:d.width*.12,y:d.height*.12,w:d.width*.7,h:type==='text'?100:240,rotation:0,opacity:1,
      ...(type==='text'?{text:'写下你的产品亮点',fontSize:64,color:'#202238'}:{fill:'#ecebff'})};
    mutate(p=>({...p,canvas:{...p.canvas,layers:[...p.canvas.layers,layer]}}));setSelected(id);
  };
  const deleteLayer=()=>{if(!selected)return;mutate(p=>({...p,canvas:{...p.canvas,layers:p.canvas.layers.filter(l=>l.id!==selected)}}));setSelected(null);};
  const startDrag=(e:ReactPointerEvent<SVGElement>,layer:Layer,resize=false)=>{
    e.stopPropagation();e.currentTarget.setPointerCapture(e.pointerId);
    setSelected(layer.id);setUndo(list=>[...list.slice(-24),structuredClone(projectRef.current)]);
    drag.current={id:layer.id,x:e.clientX,y:e.clientY,layer:{...layer},resize};
  };
  const onMove=(e:ReactPointerEvent<SVGSVGElement>)=>{
    const g=drag.current,bounds=svgRef.current?.getBoundingClientRect();if(!g||!bounds)return;
    const dx=(e.clientX-g.x)*project.canvas.width/bounds.width,dy=(e.clientY-g.y)*project.canvas.height/bounds.height;
    const next=g.resize?{...g.layer,w:Math.max(40,Math.round(g.layer.w+dx)),h:Math.max(40,Math.round(g.layer.h+dy))}:moveLayer(g.layer,dx,dy,project.canvas.width,project.canvas.height);
    mutate(p=>({...p,canvas:{...p.canvas,layers:p.canvas.layers.map(l=>l.id===g.id?next:l)}}),false);
  };
  const undoEdit=()=>{const last=undo.at(-1);if(!last)return;setUndo(undo.slice(0,-1));commit(last,false);setSelected(null);};
  const upload=async(files:FileList|null)=>{if(!files?.length)return;setUploading(true);
    try{let first='';for(const file of Array.from(files)){if(file.size>20*1024*1024)throw new Error('单张图片不能超过20MB');const r=await api.upload(file);first ||= r.asset_id;}
      await refresh();setReference(first);setPanel('assets');notify(`已上传 ${files.length} 张素材，原件保存在本机。`);
    }catch(e){notify(e instanceof Error?e.message:'上传失败');}finally{setUploading(false);if(fileRef.current)fileRef.current.value='';}};
  const submit=async()=>{
    if(!selectedModel||!prompt.trim())return notify('请选择可用模型并填写提示词。');
    if(kind==='video'&&!reference)return notify('请先选择视频首帧图片。');
    if(cloud&&!window.confirm(`将向火山引擎提交 ${batchCount} 个${kind==='image'?'图片':'视频'}任务并产生费用，素材可能上传至云端。是否继续？`))return;
    setBusy(true);
    try{
      const [w,h]=ratio==='1:1'?[cloud?2048:512,cloud?2048:512]:ratio==='3:4'?[cloud?1728:384,cloud?2304:512]:ratio==='9:16'?[cloud?1536:288,cloud?2688:512]:[cloud?2304:512,cloud?1728:384];
      const params:Record<string,unknown>={prompt,negative_prompt:negative,width:w,height:h,size:`${w}x${h}`,steps,seed,precision:'fp32'};
      if(kind==='video')Object.assign(params,{duration,ratio,resolution:'720p',generate_audio:false,frames:8,fps:8,probe_spec:!cloud});
      const items=makeBatch({kind,model_id:modelId,params,input_asset_id:kind==='video'?reference:null},batchCount,[[w,h]]);
      if(items.length===1)await api.createTask(items[0]);else await api.createBatch(`${project.name} · 批量生成`,items);
      setTaskDrawer(true);await refresh();notify(`已提交 ${items.length} 个任务。你可以继续编辑画布。`);
    }catch(e){notify(e instanceof ApiError?(ERRORS[e.code]||e.message):e instanceof Error?e.message:'提交失败');}finally{setBusy(false);}
  };
  const taskAction=async(t:Task,action:'cancel'|'retry')=>{
    if(action==='retry'&&(t.provider==='ark'||t.model_id.startsWith('doubao'))&&!window.confirm('从头重试可能产生新的云端费用，是否继续？'))return;
    try{if(action==='cancel'){const r=await api.cancelTask(t.id);notify(r.message||(r.result==='cancel_requested'?'已请求停止，将在安全点处理。':'任务已取消'));}else{await api.retryTask(t.id);notify('已提交从头重试任务。');}await refresh();}catch(e){notify(e instanceof Error?e.message:'操作失败');}
  };
  const exportPng=async()=>{setExporting(true);try{downloadBlob(await renderCanvas(projectRef.current),`${safeName(project.name)}.png`);notify('画布 PNG 已导出。');}catch(e){notify(e instanceof Error?e.message:'导出失败');}finally{setExporting(false);}};
  const exportSelected=async()=>{if(!marked.size)return;setExporting(true);try{const zip=new JSZip();const list=assets.filter(a=>marked.has(a.id));
    for(let i=0;i<list.length;i++){const a=list[i],response=await fetch(mediaUrl(a.id));if(!response.ok)throw new Error('素材下载失败，未生成不完整压缩包');zip.file(`${String(i+1).padStart(2,'0')}-${a.id}.${a.kind==='video'?'mp4':a.mime.includes('jpeg')?'jpg':'png'}`,await response.blob());}
    zip.file('素材记录.json',JSON.stringify(list.map(a=>({id:a.id,name:assetName(a),width:a.width,height:a.height,sku:project.assetGroups[a.id]||'',metadata:metadata(a)})),null,2));
    downloadBlob(await zip.generateAsync({type:'blob'}),`${safeName(project.name)}-素材.zip`);notify('选中素材已打包导出。');
    }catch(e){notify(e instanceof Error?e.message:'打包失败');}finally{setExporting(false);}};

  const gallery=(compact=false)=><div className={compact?'asset-grid compact':'asset-grid'}>{filteredAssets.map(a=><article className="asset-card" key={a.id}>
    <button className="asset-visual" onClick={()=>setPreview(a)} aria-label={`预览${assetName(a)}`}>{a.kind==='image'?<img src={mediaUrl(a.id)} loading="lazy" alt={assetName(a)}/>:<video src={mediaUrl(a.id)} preload="metadata"/>}<span className="asset-kind">{a.kind==='video'?<Film size={12}/>:<ImageIcon size={12}/>}</span></button>
    <div className="asset-caption"><span>{assetName(a)}</span><button className="mini-button" title="加入画布" onClick={()=>addAsset(a)}><Plus size={14}/></button></div>
    {!compact&&<div className="asset-bottom"><label><input type="checkbox" checked={marked.has(a.id)} onChange={()=>setMarked(old=>{const n=new Set(old);if(n.has(a.id))n.delete(a.id);else n.add(a.id);return n;})}/>选择</label><span>{a.source==='upload'?'已上传':'已生成'}</span></div>}
  </article>)}{!filteredAssets.length&&<div className="empty-state"><ImageIcon size={26}/><strong>素材从这里开始</strong><span>上传商品图，或生成第一张图片。</span><button className="secondary" onClick={()=>fileRef.current?.click()}><Upload size={14}/>上传素材</button></div>}</div>;

  return <div className="app-shell">
    <aside className="rail"><button className="brand" title="物料间" onClick={()=>setView('canvas')}><span/><span/><span/><span/></button><div className="rail-items">
      <button className={view==='canvas'?'rail-item current':'rail-item'} onClick={()=>setView('canvas')}><LayoutGrid size={20}/><span>工作台</span></button>
      <button className={view==='library'?'rail-item current':'rail-item'} onClick={()=>setView('library')}><FolderOpen size={20}/><span>素材库</span></button>
      <button className="rail-item" onClick={()=>setTaskDrawer(true)}><Clock3 size={20}/><span>任务</span>{activeTasks.length>0&&<i>{activeTasks.length}</i>}</button>
    </div><div className="rail-bottom"><span className="local-avatar">本</span><small>本地项目</small></div></aside>
    <div className="app-main">
      <header className="topbar"><div className="wordmark">物料间<span>AI STUDIO</span></div><div className="breadcrumb">我的工作空间 <span>/</span> 电商视觉创作</div><div className="header-right"><span className={`connection ${connected?'online':''}`}><i/>{connected?'服务已连接':'正在连接服务'}</span><button className="task-top" onClick={()=>setTaskDrawer(true)}><Clock3 size={15}/>任务中心{activeTasks.length>0&&<b>{activeTasks.length}</b>}</button><span className="avatar">我</span></div></header>
      <div className="projectbar"><div className="project-name"><span className="project-icon"><Layers size={17}/></span><input aria-label="项目名称" value={project.name} onChange={e=>mutate(p=>({...p,name:e.target.value}),false)}/><ChevronDown size={14}/><span className="save-status">{saveState==='已保存到本机'?<Check size={12}/>:saveState==='保存中…'?<Loader2 size={12} className="spin"/>:<span className="small-dot"/>}{saveState}</span></div><div className="project-actions"><button className="secondary" onClick={()=>void saveProject()}><Save size={14}/>保存草稿</button><button className="primary" disabled={exporting} onClick={()=>void exportPng()}>{exporting?<Loader2 size={15} className="spin"/>:<Download size={15}/>}导出画布<ChevronDown size={12}/></button></div></div>
      {notice&&<div className="toast" role="status"><span>{notice}</span><button aria-label="关闭提示" onClick={()=>setNotice('')}><X size={15}/></button></div>}
      <div className="workspace">
        <aside className="creation-panel"><div className="panel-tabs"><button className={panel==='generate'?'selected':''} onClick={()=>setPanel('generate')}><Sparkles size={15}/>AI 生成</button><button className={panel==='assets'?'selected':''} onClick={()=>setPanel('assets')}><ImageIcon size={15}/>我的素材</button></div>
          {panel==='generate'?<div className="generation-content"><div className="section-kicker">从一个灵感，到一组素材</div><h2>让商品，被看见<span> ✦</span></h2><div className="kind-switch"><button className={kind==='image'?'selected':''} onClick={()=>setKind('image')}><ImageIcon size={15}/>图片生成</button><button className={kind==='video'?'selected':''} onClick={()=>setKind('video')}><Film size={15}/>商品视频</button></div>
            <label className="field-label">生成模型<span>{cloud?'云端推理':'本机推理'}</span></label><select aria-label="生成模型" value={modelId} onChange={e=>setModelId(e.target.value)}><option value="" disabled>选择可用模型</option>{models.filter(m=>m.kind===kind).map(m=><option key={m.id} value={m.id} disabled={!m.downloaded}>{m.name}{m.downloaded?'':' · 未就位'}</option>)}</select>
            {kind==='video'&&<><label className="field-label">首帧商品图</label><button className="reference-picker" onClick={()=>setPanel('assets')}>{refAsset?<><img src={mediaUrl(refAsset.id)} alt="已选首帧"/><span>已选首帧 · 点击更换</span></>:<><Upload size={20}/><span>从素材库选择一张图片</span></>}</button><p className="microcopy">首帧图片会发送至模型服务生成视频。</p></>}
            <label className="field-label" htmlFor="prompt">{kind==='image'?'描述你想要的画面':'描述镜头与商品运动'}<Sparkles size={13}/></label><textarea id="prompt" value={prompt} onChange={e=>setPrompt(e.target.value)} rows={5}/><div className="preset-tags">{PRESETS.map(p=><button key={p.label} onClick={()=>setPrompt(p.prompt)}>{p.label}</button>)}</div>
            <label className="field-label">画面比例<span>生成尺寸与画布独立</span></label><div className="ratio-options">{['1:1','3:4','4:3','9:16'].map(r=><button key={r} onClick={()=>setRatio(r)} className={ratio===r?'selected':''}><span className={`ratio-shape r${r.replace(':','')}`}/>{r}</button>)}</div>
            <div className="field-pair"><label>生成数量<input aria-label="生成数量" type="number" min={1} max={6} value={batchCount} onChange={e=>setBatchCount(Math.max(1,Math.min(6,Number(e.target.value))))}/></label>{kind==='video'?<label>视频时长<select aria-label="视频时长" value={duration} onChange={e=>setDuration(Number(e.target.value))}><option value={5}>5 秒</option><option value={10}>10 秒</option></select></label>:<label>随机种子<input aria-label="随机种子" type="number" value={seed} onChange={e=>setSeed(Number(e.target.value))}/></label>}</div>
            <details className="advanced"><summary><SlidersHorizontal size={14}/>更多设置<ChevronDown size={13}/></summary><label>负向提示词<textarea rows={2} value={negative} onChange={e=>setNegative(e.target.value)}/></label>{!cloud&&<label>采样步数<input type="number" min={1} max={50} value={steps} onChange={e=>setSteps(Math.max(1,Math.min(50,Number(e.target.value))))}/></label>}<p>固定种子便于复现，不代表商品或 SKU 一致性保证。</p></details>
            <div className="generation-footer"><div className="usage-note"><Cloud size={13}/>{cloud?'素材将交给云端模型处理':'由本机模型计算'}<span>{usage.budget_cny>0?`今日 ¥${usage.spent_today_cny.toFixed(2)} / ¥${usage.budget_cny.toFixed(0)}`:''}</span></div><button className="generate-button" disabled={busy||!selectedModel?.downloaded||!connected} onClick={()=>void submit()}>{busy?<Loader2 size={17} className="spin"/>:<Sparkles size={17}/>}生成{batchCount>1?` ${batchCount} 个`:'素材'}<ArrowUpRight size={17}/></button><p className="microcopy">任务在后台进行，画布可以继续编辑。</p></div>
          </div>:<div className="asset-panel-content"><button className="upload-zone" onClick={()=>fileRef.current?.click()}>{uploading?<Loader2 size={24} className="spin"/>:<Upload size={24}/>}<strong>上传商品素材</strong><span>JPG / PNG / WebP · 每张不超过20MB</span></button><label className="searchbox"><Search size={14}/><input placeholder="搜索素材或 SKU" value={query} onChange={e=>setQuery(e.target.value)}/></label><p className="microcopy">点击图片预览；点 ＋ 加入画布。视频首帧可在预览中选择。</p>{gallery(true)}</div>}
        </aside>
        <main className="editor-main">
          {view==='library'?<><div className="library-heading"><div><span className="section-kicker">ASSET LIBRARY</span><h1>让每一次创作，都有迹可循。</h1><p>{assets.length} 份本机素材，随时回到画布。</p></div><button className="secondary" disabled={!marked.size||exporting} onClick={()=>void exportSelected()}><Download size={14}/>打包导出{marked.size?` (${marked.size})`:''}</button></div><div className="library-filters">{[['all','全部素材'],['image','图片'],['video','视频'],['upload','上传原图']].map(([id,label])=><button className={assetTab===id?'selected':''} onClick={()=>setAssetTab(id)} key={id}>{label}</button>)}<label className="searchbox"><Search size={14}/><input placeholder="搜索素材" value={query} onChange={e=>setQuery(e.target.value)}/></label></div><div className="library-scroll">{gallery()}</div></>:<>
            <div className="canvas-heading"><div><span className="section-kicker">CREATIVE CANVAS</span><h1>创作画布<span>将灵感，变成下一张好图。</span></h1></div><span className="canvas-size-label">{project.canvas.width} × {project.canvas.height} px</span></div>
            <div className="canvas-stage" onClick={()=>setSelected(null)}><div className="floating-tools" onClick={e=>e.stopPropagation()}><IconButton label="选择与移动" active onClick={()=>undefined}><MousePointer2 size={18}/></IconButton><i/><IconButton label="添加文字" onClick={()=>addElement('text')}><Type size={18}/></IconButton><IconButton label="添加色块" onClick={()=>addElement('shape')}><Square size={17}/></IconButton><IconButton label="添加图片" onClick={()=>{setPanel('assets');fileRef.current?.click();}}><ImageIcon size={18}/></IconButton><i/><IconButton label="撤销" disabled={!undo.length} onClick={undoEdit}><Undo2 size={17}/></IconButton></div>
              <div className="canvas-paper" style={{aspectRatio:`${project.canvas.width}/${project.canvas.height}`,transform:`scale(${zoom})`}} onClick={e=>e.stopPropagation()}>
                <svg ref={svgRef} viewBox={`0 0 ${project.canvas.width} ${project.canvas.height}`} role="img" aria-label="商品创作画布" onPointerMove={onMove} onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onPointerDown={()=>setSelected(null)} style={{background:project.canvas.background}}>
                  {project.canvas.layers.map(l=><g key={l.id} opacity={l.opacity} transform={`translate(${l.x} ${l.y}) rotate(${l.rotation} ${l.w/2} ${l.h/2})`} onPointerDown={e=>startDrag(e,l)} className="canvas-layer">
                    {l.type==='image'?<image href={mediaUrl(l.assetId!)} width={l.w} height={l.h} preserveAspectRatio="none"/>:l.type==='shape'?<rect width={l.w} height={l.h} fill={l.fill||'#ecebff'}/>:<><rect width={l.w} height={l.h} fill="transparent"/><text fill={l.color||'#202238'} fontSize={l.fontSize||64} fontWeight="600" dominantBaseline="hanging">{(l.text||'').split('\n').map((line,i)=><tspan key={i} x={0} y={i*(l.fontSize||64)*1.3}>{line}</tspan>)}</text></>}
                    {selected===l.id&&<><rect width={l.w} height={l.h} fill="none" stroke="#6965e8" strokeWidth={2} vectorEffect="non-scaling-stroke" pointerEvents="none"/><rect x={l.w-12} y={l.h-12} width={24} height={24} fill="white" stroke="#6965e8" strokeWidth={2} vectorEffect="non-scaling-stroke" className="resize-handle" onPointerDown={e=>startDrag(e,l,true)}/></>}
                  </g>)}
                </svg>
                {!project.canvas.layers.length&&<div className="canvas-empty"><div className="empty-illustration"><ImageIcon size={34}/><span>✦</span></div><strong>你的下一张主图，从这里开始</strong><p>添加一张商品图，或让 AI 帮你创造灵感。</p><button className="secondary" onClick={()=>setPanel('assets')}><Plus size={14}/>添加素材</button></div>}
              </div>
              <div className="zoom-controls" onClick={e=>e.stopPropagation()}><IconButton label="缩小画布" onClick={()=>setZoom(Math.max(.5,zoom-.1))}><Minus size={14}/></IconButton><button onClick={()=>setZoom(1)}>{Math.round(zoom*100)}%</button><IconButton label="放大画布" onClick={()=>setZoom(Math.min(1.3,zoom+.1))}><Plus size={14}/></IconButton><span/><button onClick={()=>setZoom(1)}>适应画布</button></div>
            </div>
            <div className="recent-strip"><div className="strip-heading"><strong>最近的灵感<span>{assets.filter(a=>a.source==='generated'||a.source==='cloud_generated').length}</span></strong><button onClick={()=>setView('library')}>查看全部<ChevronDown size={12}/></button></div><div className="recent-items">{assets.filter(a=>(a.source==='generated'||a.source==='cloud_generated')&&a.size>2048).slice(0,8).map(a=><button key={a.id} className="recent-item" onClick={()=>addAsset(a)} aria-label="将最近素材加入画布">{a.kind==='image'?<img src={mediaUrl(a.id)} alt="真实生成素材"/>:<Film size={24}/>}<span><Plus size={12}/></span></button>)}<button className="recent-upload" onClick={()=>fileRef.current?.click()}><Upload size={18}/><span>上传素材</span></button></div></div>
          </>}
        </main>
        <aside className="properties"><div className="properties-title"><SlidersHorizontal size={16}/> {selectedLayer?'图层属性':'画布设置'}</div>
          {selectedLayer?<div className="property-content"><label>图层名称<input value={selectedLayer.name} onChange={e=>updateLayer({name:e.target.value})}/></label>{selectedLayer.type==='text'&&<><label>文案<textarea rows={3} value={selectedLayer.text} onChange={e=>updateLayer({text:e.target.value})}/></label><div className="field-pair"><label>字号<input type="number" min={8} value={selectedLayer.fontSize} onChange={e=>updateLayer({fontSize:Math.max(8,Number(e.target.value))})}/></label><label>颜色<input type="color" value={selectedLayer.color} onChange={e=>updateLayer({color:e.target.value})}/></label></div></>}{selectedLayer.type==='shape'&&<label>填充颜色<input type="color" value={selectedLayer.fill} onChange={e=>updateLayer({fill:e.target.value})}/></label>}
            <div className="field-pair">{(['x','y','w','h'] as const).map(k=><label key={k}>{({x:'X 位置',y:'Y 位置',w:'宽度',h:'高度'})[k]}<input aria-label={`图层${k}`} type="number" value={Math.round(selectedLayer[k])} onChange={e=>updateLayer({[k]:k==='w'||k==='h'?Math.max(20,Number(e.target.value)):Number(e.target.value)})}/></label>)}</div><label>不透明度 <span>{Math.round(selectedLayer.opacity*100)}%</span><input type="range" min={0} max={1} step={.05} value={selectedLayer.opacity} onChange={e=>updateLayer({opacity:Number(e.target.value)})}/></label><label>旋转<input type="number" value={selectedLayer.rotation} onChange={e=>updateLayer({rotation:Number(e.target.value)})}/></label><div className="layer-actions"><button className="secondary" onClick={()=>{const copy={...selectedLayer,id:crypto.randomUUID(),x:selectedLayer.x+30,y:selectedLayer.y+30,name:selectedLayer.name+' 副本'};mutate(p=>({...p,canvas:{...p.canvas,layers:[...p.canvas.layers,copy]}}));setSelected(copy.id);}}><Copy size={13}/>复制</button><button className="secondary" onClick={deleteLayer}><Trash2 size={13}/>移除</button></div>
          </div>:<div className="property-content"><label>画布比例<select aria-label="画布比例" value={`${project.canvas.width}:${project.canvas.height}`} onChange={e=>{const [width,height]=e.target.value.split(':').map(Number);mutate(p=>({...p,canvas:{...p.canvas,width,height}}));}}>{[[1080,1080,'1:1 · 商品主图'],[1080,1440,'3:4 · 内容封面'],[1080,1920,'9:16 · 竖版内容'],[1920,1080,'16:9 · 横版内容']].map(([w,h,name])=><option key={name} value={`${w}:${h}`}>{name}</option>)}</select></label><div className="field-pair"><label>宽度<input readOnly value={project.canvas.width}/></label><label>高度<input readOnly value={project.canvas.height}/></label></div><label>背景颜色<input aria-label="画布背景颜色" type="color" value={project.canvas.background} onChange={e=>mutate(p=>({...p,canvas:{...p.canvas,background:e.target.value}}))}/></label><div className="tip-card"><Sparkles size={17}/><strong>给商品，多一点表达</strong><p>将素材加入画布，叠加文案与色块。生成期间也能继续编辑。</p></div></div>}
          <div className="layer-section"><div className="properties-title"><Layers size={15}/>图层<span>{project.canvas.layers.length}</span></div>{project.canvas.layers.length?<div className="layer-list">{[...project.canvas.layers].reverse().map((l,i)=><div className={l.id===selected?'layer-row selected':'layer-row'} key={l.id}><button onClick={()=>setSelected(l.id)}>{l.type==='image'?<ImageIcon size={15}/>:l.type==='text'?<Type size={15}/>:<Square size={15}/>}<span>{l.name}</span></button><button title="上移一层" disabled={i===0} onClick={()=>mutate(p=>{const layers=[...p.canvas.layers],n=layers.findIndex(x=>x.id===l.id);[layers[n],layers[n+1]]=[layers[n+1],layers[n]];return {...p,canvas:{...p.canvas,layers}};})}>↑</button></div>)}</div>:<p className="empty-layers">添加素材后，图层会显示在这里。</p>}</div><div className="properties-footer"><span className="green-dot"/>素材与草稿保存在本机</div>
        </aside>
      </div>
      <footer className="statusbar"><span><span className="green-dot"/>本地工作台 · 云端模型可选</span><span>{system?`排队 ${system.queue.queued} · 执行 ${system.queue.active}`:'等待连接'}<i/>画布编辑不占用生成队列</span></footer>
    </div>
    <input ref={fileRef} className="hidden" type="file" accept="image/png,image/jpeg,image/webp" multiple onChange={e=>void upload(e.target.files)}/>
    {preview&&<div className="modal-backdrop" onClick={()=>setPreview(null)}><section className="preview-modal" role="dialog" aria-modal="true" aria-label="素材预览" onClick={e=>e.stopPropagation()}><header><div><strong>{assetName(preview)}</strong><span>{preview.width}×{preview.height} · {(preview.size/1e6).toFixed(2)} MB</span></div><IconButton label="关闭预览" onClick={()=>setPreview(null)}><X size={20}/></IconButton></header><div className="preview-media">{preview.kind==='image'?<img src={mediaUrl(preview.id)} alt={assetName(preview)}/>:<video src={mediaUrl(preview.id)} controls autoPlay/>}</div><div className="preview-actions"><a className="secondary" href={mediaUrl(preview.id)} download><ArrowDownToLine size={15}/>下载原文件</a>{preview.kind==='image'&&<><button className="secondary" onClick={()=>{setReference(preview.id);setPreview(null);setPanel('generate');setKind('video');notify('已选为视频首帧。');}}><Film size={15}/>用作视频首帧</button><button className="primary" onClick={()=>{addAsset(preview);setPreview(null);}}>加入画布<Plus size={15}/></button></>}</div><label className="sku-label">SKU 分组（仅用于项目内管理）<input placeholder="例如：面霜系列 / 白色款" value={project.assetGroups[preview.id]||''} onChange={e=>mutate(p=>({...p,assetGroups:{...p.assetGroups,[preview.id]:e.target.value}}),false)}/></label></section></div>}
    {taskDrawer&&<div className="drawer-backdrop" onClick={()=>setTaskDrawer(false)}><aside className="task-drawer" role="dialog" aria-label="任务中心" onClick={e=>e.stopPropagation()}><header><div><span className="section-kicker">TASK CENTER</span><h2>让创作持续发生</h2></div><IconButton label="关闭任务中心" onClick={()=>setTaskDrawer(false)}><X size={20}/></IconButton></header><div className="queue-summary"><span><b>{activeTasks.length}</b>进行中</span><span><b>{tasks.filter(t=>t.status==='succeeded').length}</b>已完成</span><button className="secondary" onClick={()=>void refresh()}><RefreshCw size={13}/>刷新</button></div><p className="drawer-hint">真实后端状态 · 生成结果不会覆盖画布编辑</p><div className="task-list">{tasks.map(t=>{const a=assets.find(a=>a.id===t.output_asset_id);return <article className="task-card" key={t.id}><div className="task-card-top"><div className="task-symbol">{t.kind==='image'?<ImageIcon size={17}/>:<Film size={17}/>}</div><div><strong>{t.kind==='image'?'图片生成':'商品视频'}</strong><small>{t.model_id.replace('doubao-','')}</small></div><span className={`task-badge ${t.status}`}>{ACTIVE.includes(t.status)&&<Loader2 size={11} className="spin"/>}{NAMES[t.status]||t.status}</span></div>{ACTIVE.includes(t.status)&&<div className="progress-track"><span style={{width:`${Math.max(3,t.progress*100)}%`}}/></div>}{t.error_message&&<p className="task-error">{ERRORS[t.error_code||'']||t.error_message}</p>}{a&&<button className="task-result" onClick={()=>setPreview(a)}>{a.kind==='image'?<img src={mediaUrl(a.id)} alt="任务真实结果"/>:<Film size={22}/>}<span>查看生成结果<ArrowUpRight size={14}/></span></button>}<div className="task-meta"><span>{time(t.latency_ms)}</span><span>{t.provider==='ark'||t.model_id.startsWith('doubao')?'云端':'本地'}{t.cost_cny!=null?` · ¥${t.cost_cny.toFixed(2)}`:''}</span></div><div className="task-actions">{ACTIVE.includes(t.status)&&<button className="secondary" onClick={()=>void taskAction(t,'cancel')}>请求取消</button>}{['failed','interrupted','canceled'].includes(t.status)&&t.error_code!=='CREATE_RESULT_UNKNOWN'&&<button className="secondary" onClick={()=>void taskAction(t,'retry')}><RefreshCw size={12}/>从头重试</button>}{a?.kind==='image'&&<button className="secondary" onClick={()=>{addAsset(a);setTaskDrawer(false);}}>加入画布<Plus size={12}/></button>}</div></article>;})}{!tasks.length&&<div className="empty-state"><Clock3 size={26}/><strong>还没有生成任务</strong><span>在左侧描述画面，开始第一次生成。</span></div>}</div></aside></div>}
  </div>;
}
